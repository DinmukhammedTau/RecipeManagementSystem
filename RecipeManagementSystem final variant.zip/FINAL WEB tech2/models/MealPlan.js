const mongoose = require("mongoose");

const MealPlanSchema = new mongoose.Schema({
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    date: { type: Date, required: true },
    meals: [
        { 
            time: String, // Breakfast, Lunch, Dinner
            recipe: { type: mongoose.Schema.Types.ObjectId, ref: "Recipe" }
        }
    ]
});

module.exports = mongoose.model("MealPlan", MealPlanSchema);
