const Joi = require("joi");

// ✅ Валидация регистрации
const registerValidation = (req, res, next) => {
    const schema = Joi.object({
        username: Joi.string().min(3).max(30).required().messages({
            "string.empty": "Имя пользователя обязательно",
            "string.min": "Имя пользователя должно содержать минимум 3 символа",
            "string.max": "Имя пользователя не должно превышать 30 символов"
        }),
        email: Joi.string().email().required().messages({
            "string.email": "Введите корректный email",
            "string.empty": "Email обязателен"
        }),
        password: Joi.string().min(6).required().messages({
            "string.empty": "Пароль обязателен",
            "string.min": "Пароль должен содержать минимум 6 символов"
        })
    });

    const { error } = schema.validate(req.body);
    if (error) {
        return res.render("register", { error: error.details[0].message });
    }
    next();
};

// ✅ Валидация входа в систему
const loginValidation = (req, res, next) => {
    const schema = Joi.object({
        email: Joi.string().email().required().messages({
            "string.email": "Введите корректный email",
            "string.empty": "Email обязателен"
        }),
        password: Joi.string().min(6).required().messages({
            "string.empty": "Пароль обязателен",
            "string.min": "Пароль должен содержать минимум 6 символов"
        })
    });

    const { error } = schema.validate(req.body);
    if (error) {
        return res.render("login", { error: error.details[0].message });
    }
    next();
};

module.exports = { registerValidation, loginValidation };
