const jwt = require("jsonwebtoken");
const User = require("../models/User");

module.exports = async (req, res, next) => {
    try {
        const token = req.cookies.token; // ✅ Читаем токен из куки
        if (!token) return res.redirect("/login");

        const decoded = jwt.verify(token, process.env.JWT_SECRET); // ✅ Декодируем токен
        const user = await User.findById(decoded.id).select("username email"); // ✅ Берём данные пользователя

        if (!user) {
            res.clearCookie("token");
            return res.redirect("/login");
        }

        req.user = user; // ✅ Добавляем пользователя в `req.user`
        next();
    } catch (error) {
        res.clearCookie("token");
        res.redirect("/login");
    }
};

