const errorHandler = (err, req, res, next) => {
    console.error("❌ Ошибка:", err.message);
    res.status(500).render("error", { error: "Внутренняя ошибка сервера. Попробуйте позже." });
};

module.exports = errorHandler;
