// ✅ Fetch all recipes and display them
async function fetchRecipes() {
    try {
        const response = await fetch("http://localhost:5000/api/recipes");
        const recipes = await response.json();

        const recipeList = document.getElementById("recipe-list");
        recipeList.innerHTML = "";

        if (recipes.length === 0) {
            recipeList.innerHTML = "<p>No recipes found.</p>";
            return;
        }

        recipes.forEach(recipe => {
            recipeList.innerHTML += `
                <li>
                    <h3>${recipe.name}</h3>
                    <p><strong>Category:</strong> ${recipe.category.join(", ")}</p>
                    <p><strong>Instructions:</strong> ${recipe.instructions}</p>
                    <button onclick="deleteRecipe('${recipe._id}')">Delete</button>
                </li>
            `;
        });
    } catch (error) {
        console.error("Error fetching recipes:", error);
    }
}

// ✅ Add a new recipe
async function addRecipe() {
    const name = document.getElementById("recipe-name").value.trim();
    const category = document.getElementById("recipe-category").value.trim();
    const instructions = document.getElementById("recipe-instructions").value.trim();

    if (!name || !category || !instructions) {
        alert("All fields are required!");
        return;
    }

    try {
        const response = await fetch("/api/recipes", {
            method: "POST",
            headers: { 
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ 
                name, 
                category: category.split(",").map(c => c.trim()),  // ✅ Convert string to array
                instructions 
            })
        });

        const data = await response.json();

        if (response.ok) {
            alert(data.message || "Recipe added successfully!");

            // ✅ Add the new recipe to the UI immediately
            const recipeList = document.getElementById("recipe-list");
            const newRecipe = document.createElement("li");
            newRecipe.innerHTML = `
                <h3>${data.recipe.name}</h3>
                <p><strong>Category:</strong> ${data.recipe.category.join(", ")}</p>
                <p><strong>Instructions:</strong> ${data.recipe.instructions}</p>
                <button onclick="deleteRecipe('${data.recipe._id}')">Delete</button>
            `;
            recipeList.appendChild(newRecipe);

            // ✅ Clear input fields after adding
            document.getElementById("recipe-name").value = "";
            document.getElementById("recipe-category").value = "";
            document.getElementById("recipe-instructions").value = "";
        } else {
            alert(data.message || "Failed to add recipe.");
        }
    } catch (error) {
        console.error("Error adding recipe:", error);
        alert("An error occurred while adding the recipe.");
    }
}


// ✅ Delete a recipe
async function deleteRecipe(recipeId) {
    if (!confirm("Are you sure you want to delete this recipe?")) return;

    try {
        const response = await fetch(`/api/recipes/${recipeId}`, {
            method: "DELETE",
            headers: { "Content-Type": "application/json" }
        });

        const data = await response.json();

        if (response.ok) {
            alert(data.message || "Recipe deleted successfully!");

            // ✅ Remove the recipe from the UI immediately
            const recipeElement = document.getElementById(`recipe-${recipeId}`);
            if (recipeElement) {
                recipeElement.remove();
            }
        } else {
            alert(data.message || "Failed to delete recipe.");
        }
    } catch (error) {
        console.error("Error deleting recipe:", error);
        alert("An error occurred while deleting the recipe.");
    }
}


// ✅ Search & filter recipes
async function searchRecipes() {
    const query = document.getElementById("search-input").value;
    const category = document.getElementById("category-filter").value;

    let url = `http://localhost:5000/api/recipes/search?query=${query}`;
    if (category) url += `&category=${category}`;

    try {
        const response = await fetch(url);
        const recipes = await response.json();

        const recipeList = document.getElementById("recipe-list");
        recipeList.innerHTML = "";

        if (recipes.length === 0) {
            recipeList.innerHTML = "<p>No recipes found.</p>";
            return;
        }

        recipes.forEach(recipe => {
            recipeList.innerHTML += `
                <li>
                    <h3>${recipe.name}</h3>
                    <p><strong>Category:</strong> ${recipe.category.join(", ")}</p>
                    <p><strong>Instructions:</strong> ${recipe.instructions}</p>
                    <button onclick="deleteRecipe('${recipe._id}')">Delete</button>
                </li>
            `;
        });
    } catch (error) {
        console.error("Error searching recipes:", error);
    }
}

// ✅ Fetch recipes on page load
document.addEventListener("DOMContentLoaded", fetchRecipes);

