const express = require("express");
const Recipe = require("../models/Recipe");
const auth = require("../middleware/auth");
const router = express.Router();

// ✅ Add a recipe
router.post("/", auth, async (req, res) => {
    try {
        const { name, category, instructions } = req.body;

        if (!name || !category || !instructions) {
            return res.status(400).json({ message: "All fields are required!" });
        }

        const newRecipe = new Recipe({
            name,
            category, // ✅ No `.split(",")`, because it's already an array
            instructions
        });

        await newRecipe.save();
        res.json({ message: "Recipe added successfully!", recipe: newRecipe });
    } catch (error) {
        console.error("❌ Error adding recipe:", error);
        res.status(500).json({ message: "Error adding recipe" });
    }
});


// ✅ Search recipes
router.get("/search", async (req, res) => {
    try {
        const { query, category } = req.query;
        let filter = {};

        if (query) filter.name = new RegExp(query, "i");
        if (category) filter.category = category;

        const recipes = await Recipe.find(filter);
        res.json(recipes);
    } catch (error) {
        res.status(500).json({ message: "Error searching recipes" });
    }
});

router.delete("/:id", auth, async (req, res) => {
    try {
        const recipe = await Recipe.findByIdAndDelete(req.params.id);
        if (!recipe) {
            return res.status(404).json({ message: "Recipe not found" });
        }
        res.json({ message: "Recipe deleted successfully!" });
    } catch (error) {
        console.error("❌ Error deleting recipe:", error);
        res.status(500).json({ message: "Error deleting recipe" });
    }
});

module.exports = router;
