const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const { registerValidation, loginValidation } = require("../middleware/validate");
const router = express.Router();

// ✅ POST /register - Регистрация с валидацией
router.post("/register", registerValidation, async (req, res) => {
    try {
        const { username, email, password } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10);
        const user = new User({ username, email, password: hashedPassword });
        await user.save();

        const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
        res.cookie("token", token, { httpOnly: true }).redirect("/");
    } catch (error) {
        if (error.code === 11000) {
            if (error.keyPattern.username) {
                return res.render("register", { error: "Такой ник уже занят" });
            } else if (error.keyPattern.email) {
                return res.render("register", { error: "Этот email уже зарегистрирован" });
            }
        }
        res.render("register", { error: "Ошибка регистрации. Попробуйте снова." });
    }
});

// ✅ POST /login - Вход в систему с валидацией
router.post("/login", loginValidation, async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await User.findOne({ email });
        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.render("login", { error: "Неверный email или пароль" });
        }

        const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
        res.cookie("token", token, { httpOnly: true }).redirect("/");
    } catch (error) {
        res.render("login", { error: "Ошибка входа. Попробуйте снова." });
    }
});

module.exports = router;
