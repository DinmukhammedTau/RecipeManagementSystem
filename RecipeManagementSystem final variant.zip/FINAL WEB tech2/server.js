require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const path = require("path");
const cookieParser = require("cookie-parser");

const recipeRoutes = require("./routes/recipeRoutes");
const userRoutes = require("./routes/userRoutes");
const authRoutes = require("./routes/authRoutes");
const auth = require("./middleware/auth"); // ✅ Подключаем middleware
const Recipe = require("./models/Recipe");

const app = express();

// ✅ Настройка EJS
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Включаем CORS, JSON-парсинг и Cookie-парсинг
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser()); // ✅ Позволяет работать с куки

// ✅ Подключаем статику (CSS, JS)
app.use(express.static(path.join(__dirname, "public")));

// ✅ Подключение к MongoDB
mongoose.connect(process.env.MONGO_URI, { 
    useNewUrlParser: true, 
    useUnifiedTopology: true 
})
    .then(() => console.log("✅ MongoDB Connected"))
    .catch((err) => {
        console.error("❌ MongoDB Connection Error:", err.message);
        process.exit(1);
    });


    

    
// ✅ Защищаем главную страницу (только для авторизованных пользователей)
app.get("/", auth, async (req, res) => {
    try {
        const recipes = await Recipe.find().limit(5);
        res.render("index", { recipes, user: req.user }); // ✅ Передаём пользователя в шаблон
    } catch (error) {
        res.render("index", { recipes: [], user: null });
    }
});


// ✅ Защищаем страницу рецептов (только для авторизованных пользователей)
app.get("/recipes", auth, async (req, res) => {
    try {
        const recipes = await Recipe.find();
        res.render("recipes", { recipes });
    } catch (error) {
        res.render("recipes", { recipes: [] });
    }
});

// ✅ Открытые маршруты (доступны без входа)
app.get("/register", (req, res) => res.render("register", { error: null }));
app.get("/login", (req, res) => res.render("login", { error: null }));
app.get("/options", (req, res) => {
    res.render("options");
});

// ✅ Выход (очищает токен и перенаправляет на вход)
app.get("/logout", (req, res) => {
    res.clearCookie("token").redirect("/login");
});
// ✅ Подключаем API маршруты
app.use("/api/recipes", recipeRoutes);
app.use("/api/users", userRoutes);
app.use("/api/auth", authRoutes);

// Запускаем сервер
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
